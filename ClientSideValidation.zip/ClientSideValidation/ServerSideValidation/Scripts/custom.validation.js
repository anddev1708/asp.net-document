﻿$(function () {

    /*Date of Birth*/
    jQuery.validator.addMethod('validbirthdate', function (value, element, params) {
        var minDate = new Date(params["min"]);
        var maxDate = new Date(params["max"]);
        var dateValue = new Date(value);
        if (dateValue > minDate && dateValue < maxDate)
            return true;
        else
            return false;
    });

    jQuery.validator.unobtrusive.adapters.add('validbirthdate', ['min', 'max'], function (options) {
        var params = {
            min: options.params.min,
            max: options.params.max
        };

        options.rules['validbirthdate'] = params;
        if (options.message) {
            options.messages['validbirthdate'] = options.message;
        }
    });
    /*End*/

    /*Sex*/
    jQuery.validator.addMethod('sexvalidation', function (value, element, params) {
        if ((value != "M") && (value != "F"))
            return false;
        else
            return true;
    });

    jQuery.validator.unobtrusive.adapters.add('sexvalidation', function (options) {
        options.rules['sexvalidation'] = {};
        options.messages['sexvalidation'] = options.message;
    });
    /*End*/

    /*Skill*/
    jQuery.validator.addMethod('skillvalidation', function (value, element, params) {
        return false;
    });

    jQuery.validator.unobtrusive.adapters.add('skillvalidation', function (options) {
        options.rules['skillvalidation'] = {};
        options.messages['skillvalidation'] = options.message;
    });
    /*End*/

    /*Terms Validation*/
    jQuery.validator.addMethod('termsvalidation', function (value, element, params) {
        if (value != "true")
            return false;
        else
            return true;
    });

    jQuery.validator.unobtrusive.adapters.add('termsvalidation', function (options) {
        options.rules['termsvalidation'] = {};
        options.messages['termsvalidation'] = options.message;
    });
    /*End*/
   
}(jQuery));