﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using demo.MVC.Class;

namespace demo.MVC.Models
{
    public class CheckBox
    {
        public bool IsChecked { get; set; }
    }
}